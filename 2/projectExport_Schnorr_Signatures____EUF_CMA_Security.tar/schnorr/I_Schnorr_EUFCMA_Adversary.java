package schnorr;

public interface I_Schnorr_EUFCMA_Adversary<G,E> extends I_Schnorr_EUF_Adversary<G,E> {
    
}
