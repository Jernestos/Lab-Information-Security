package reductions;

import dhi.I_DHI_Adversary;
import dy05.I_DY05_Challenger;

public interface I_DHI_DY05_Reduction extends I_DHI_Adversary, I_DY05_Challenger {}
