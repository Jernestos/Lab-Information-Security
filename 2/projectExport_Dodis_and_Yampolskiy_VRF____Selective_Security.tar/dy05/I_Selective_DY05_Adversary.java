package dy05;

import basics.IAdversary;
import genericGroups.IGroupElement;

public interface I_Selective_DY05_Adversary extends IAdversary<I_DY05_Challenger, IGroupElement> {
}