package dhi;

import basics.IAdversary;
import genericGroups.IGroupElement;

public interface I_DHI_Adversary extends IAdversary<I_DHI_Challenger, IGroupElement> {
}