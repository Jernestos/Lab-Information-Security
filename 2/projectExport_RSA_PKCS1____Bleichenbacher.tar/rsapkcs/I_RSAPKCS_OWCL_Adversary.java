package rsapkcs;

import java.math.BigInteger;

import basics.IAdversary;

public interface I_RSAPKCS_OWCL_Adversary extends IAdversary<I_RSAPKCS_OWCL_Challenger, BigInteger> {}
