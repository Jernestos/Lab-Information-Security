package schnorr;

public interface I_Schnorr_EUFNMA_Challenger<G,E> extends I_Schnorr_EUF_Challenger<G,E> {
    
}
