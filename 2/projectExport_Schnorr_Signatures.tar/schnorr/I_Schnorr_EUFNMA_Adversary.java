package schnorr;

public interface I_Schnorr_EUFNMA_Adversary<G,E> extends I_Schnorr_EUF_Adversary<G,E>{
    
}
